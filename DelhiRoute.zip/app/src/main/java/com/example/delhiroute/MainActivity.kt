package com.example.delhiroute

import android.graphics.Paint
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.inputmethod.InputMethodManager
import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.example.delhiroute.databinding.ActivityMainBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.textfield.MaterialAutoCompleteTextView
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import java.io.File
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var sourceField: PlaceField
    private lateinit var destField: PlaceField
    private lateinit var eventsOverlay: MapEventsOverlay

    private var routeJob: Job? = null
    private var routeLine: Polyline? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initOsmdroid()
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupMap()
        sourceField = PlaceField(binding.sourceInput)
        destField = PlaceField(binding.destInput)
        binding.swapButton.setOnClickListener { swap() }
    }

    override fun onResume() {
        super.onResume()
        binding.map.onResume()
    }

    override fun onPause() {
        binding.map.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        binding.map.onDetach()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ setup

    private fun initOsmdroid() {
        val cfg = Configuration.getInstance()
        cfg.load(applicationContext, getSharedPreferences("osmdroid", MODE_PRIVATE))
        cfg.userAgentValue = packageName // required by OSM tile usage policy
        val base = File(cacheDir, "osmdroid").apply { mkdirs() }
        cfg.osmdroidBasePath = base
        cfg.osmdroidTileCache = File(base, "tiles").apply { mkdirs() }
    }

    private fun setupMap() {
        val map = binding.map
        map.setTileSource(TileSourceFactory.MAPNIK)
        map.setMultiTouchControls(true)
        map.zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
        map.setMinZoomLevel(10.0)
        map.setMaxZoomLevel(19.0)
        map.setScrollableAreaLimitDouble(
            BoundingBox(
                DelhiBounds.NORTH + 0.1, DelhiBounds.EAST + 0.1,
                DelhiBounds.SOUTH - 0.1, DelhiBounds.WEST - 0.1
            )
        )
        map.controller.setZoom(11.0)
        map.controller.setCenter(DELHI_CENTER)

        // Long-press anywhere on the map to drop a pin as source / destination.
        eventsOverlay = MapEventsOverlay(object : MapEventsReceiver {
            override fun singleTapConfirmedHelper(p: GeoPoint?): Boolean = false
            override fun longPressHelper(p: GeoPoint?): Boolean {
                if (p == null) return false
                map.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                if (!DelhiBounds.contains(p.latitude, p.longitude)) {
                    showMessage(R.string.outside_delhi)
                } else {
                    showPinDialog(p)
                }
                return true
            }
        })
        map.overlays.add(eventsOverlay)
    }

    // ------------------------------------------------------------ place fields

    /** Wraps one autocomplete input: debounced search, selection, and state. */
    private inner class PlaceField(val input: MaterialAutoCompleteTextView) {
        private val adapter = PlaceAdapter(this@MainActivity)
        private var suppress = false
        private var job: Job? = null

        var place: Place? = null
            private set

        init {
            input.setAdapter(adapter)
            input.threshold = 1
            input.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    if (suppress) return
                    if (place != null) {          // user edited a chosen place -> invalidate it
                        place = null
                        onPlacesChanged(focus = false)
                    }
                    search(s?.toString().orEmpty().trim())
                }
            })
            input.setOnItemClickListener { _, _, position, _ ->
                adapter.getItem(position)?.let { select(it) }
            }
        }

        fun select(p: Place) {
            setSilently(p)
            input.dismissDropDown()
            hideKeyboard()
            onPlacesChanged(focus = true)
        }

        fun setSilently(p: Place?, text: String = p?.name.orEmpty()) {
            job?.cancel()
            suppress = true
            place = p
            input.setText(text, false)
            suppress = false
        }

        private fun search(query: String) {
            job?.cancel()
            if (query.length < 2) {
                adapter.submit(emptyList())
                return
            }
            job = lifecycleScope.launch {
                delay(450) // debounce: respect Nominatim's usage policy
                try {
                    val results = GeoApi.search(query)
                    adapter.submit(results)
                    if (input.hasFocus() && results.isNotEmpty()) input.showDropDown()
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    showMessage(R.string.error_search)
                }
            }
        }
    }

    private fun swap() {
        val sp = sourceField.place
        val dp = destField.place
        val st = sourceField.input.text.toString()
        val dt = destField.input.text.toString()
        sourceField.setSilently(dp, dt)
        destField.setSilently(sp, st)
        hideKeyboard()
        onPlacesChanged(focus = false)
    }

    // ------------------------------------------------------------ map pin flow

    private fun showPinDialog(p: GeoPoint) {
        MaterialAlertDialogBuilder(this)
            .setTitle(String.format(Locale.US, "%.5f, %.5f", p.latitude, p.longitude))
            .setItems(
                arrayOf(getString(R.string.set_as_source), getString(R.string.set_as_destination))
            ) { _, which -> assignPin(p, isSource = which == 0) }
            .show()
    }

    private fun assignPin(p: GeoPoint, isSource: Boolean) {
        lifecycleScope.launch {
            val resolved: String? = try {
                GeoApi.reverse(p.latitude, p.longitude)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null
            }
            val name = resolved
                ?: String.format(Locale.US, "Pin (%.5f, %.5f)", p.latitude, p.longitude)
            val place = Place(name, p.latitude, p.longitude)
            (if (isSource) sourceField else destField).select(place)
        }
    }

    // ------------------------------------------------------------ routing

    private fun onPlacesChanged(focus: Boolean) {
        routeJob?.cancel()
        routeLine = null
        hideResult()
        refreshOverlays()

        val s = sourceField.place
        val d = destField.place
        if (s != null && d != null) {
            requestRoute(s, d)
        } else if (focus) {
            (s ?: d)?.let {
                binding.map.controller.animateTo(GeoPoint(it.lat, it.lon), 14.0, 700L)
            }
        }
    }

    private fun requestRoute(s: Place, d: Place) {
        val straight = GeoPoint(s.lat, s.lon).distanceToAsDouble(GeoPoint(d.lat, d.lon))
        if (straight < 25) {
            showMessage(R.string.same_place)
            return
        }
        showLoading()
        routeJob = lifecycleScope.launch {
            try {
                val route = GeoApi.route(s, d)
                showRoute(route, straight)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                hideResult()
                Snackbar.make(binding.root, R.string.error_route, Snackbar.LENGTH_LONG)
                    .setAction(R.string.retry) { requestRoute(s, d) }
                    .show()
            }
        }
    }

    private fun showRoute(route: RouteResult, straightMeters: Double) {
        routeLine = Polyline().apply {
            setPoints(route.points)
            outlinePaint.apply {
                color = ContextCompat.getColor(this@MainActivity, R.color.route)
                strokeWidth = 14f
                strokeCap = Paint.Cap.ROUND
                strokeJoin = Paint.Join.ROUND
                isAntiAlias = true
            }
        }
        refreshOverlays()

        binding.distanceText.text = formatDistance(route.distanceMeters)
        binding.timeText.text = formatDuration(route.durationSeconds)
        binding.noteText.text = getString(R.string.note_fmt, formatDistance(straightMeters))
        binding.progress.visibility = View.GONE
        binding.resultContent.visibility = View.VISIBLE
        binding.resultCard.visibility = View.VISIBLE

        val map = binding.map
        val box = BoundingBox.fromGeoPoints(route.points)
        val border = minOf(dp(130), minOf(map.width, map.height) / 4)
        map.post { map.zoomToBoundingBox(box, true, border) }
    }

    // ------------------------------------------------------------ overlays / UI

    private fun refreshOverlays() {
        val overlays = binding.map.overlays
        overlays.clear()
        overlays.add(eventsOverlay)
        routeLine?.let { overlays.add(it) }
        sourceField.place?.let {
            overlays.add(buildMarker(it, R.drawable.marker_source, "Source"))
        }
        destField.place?.let {
            overlays.add(buildMarker(it, R.drawable.marker_dest, "Destination"))
        }
        binding.map.invalidate()
    }

    private fun buildMarker(p: Place, @DrawableRes iconRes: Int, label: String): Marker =
        Marker(binding.map).apply {
            position = GeoPoint(p.lat, p.lon)
            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
            icon = ContextCompat.getDrawable(this@MainActivity, iconRes)
            title = "$label: ${p.name}"
        }

    private fun showLoading() {
        binding.resultCard.visibility = View.VISIBLE
        binding.resultContent.visibility = View.INVISIBLE
        binding.progress.visibility = View.VISIBLE
    }

    private fun hideResult() {
        binding.resultCard.visibility = View.GONE
    }

    private fun showMessage(@StringRes res: Int) {
        Snackbar.make(binding.root, res, Snackbar.LENGTH_SHORT).show()
    }

    private fun hideKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(binding.root.windowToken, 0)
        currentFocus?.clearFocus()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    // ------------------------------------------------------------ formatting

    private fun formatDistance(meters: Double): String =
        if (meters < 1000) "${meters.roundToInt()} m"
        else String.format(Locale.getDefault(), "%.1f km", meters / 1000.0)

    private fun formatDuration(seconds: Double): String {
        val totalMin = (seconds / 60.0).roundToInt()
        return when {
            totalMin < 1 -> getString(R.string.less_than_min)
            totalMin < 60 -> getString(R.string.fmt_min, totalMin)
            totalMin % 60 == 0 -> getString(R.string.fmt_hr, totalMin / 60)
            else -> getString(R.string.fmt_hr_min, totalMin / 60, totalMin % 60)
        }
    }

    companion object {
        private val DELHI_CENTER = GeoPoint(28.6139, 77.2090)
    }
}
