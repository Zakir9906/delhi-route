package com.example.delhiroute

import org.osmdroid.util.GeoPoint

/** A named location. [toString] is used by the autocomplete dropdown. */
data class Place(val name: String, val lat: Double, val lon: Double) {
    override fun toString(): String = name
}

data class RouteResult(
    val distanceMeters: Double,
    val durationSeconds: Double,
    val points: List<GeoPoint>
)

/** Rough bounding box of Delhi (NCT), used to restrict search and the map. */
object DelhiBounds {
    const val WEST = 76.82
    const val EAST = 77.36
    const val SOUTH = 28.39
    const val NORTH = 28.89

    /** Nominatim viewbox format: left,top,right,bottom */
    val VIEWBOX: String = "$WEST,$NORTH,$EAST,$SOUTH"

    fun contains(lat: Double, lon: Double): Boolean =
        lat in SOUTH..NORTH && lon in WEST..EAST
}
