package com.example.delhiroute

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import org.osmdroid.util.GeoPoint
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

/**
 * Network layer. Uses only free, key-less OpenStreetMap services:
 *  - Nominatim  : place search + reverse geocoding
 *  - OSRM       : driving route (distance, duration, geometry)
 */
object GeoApi {
    private const val USER_AGENT = "DelhiRouteFinder/1.0 (Android assignment app)"
    private const val NOMINATIM = "https://nominatim.openstreetmap.org"
    private const val OSRM = "https://router.project-osrm.org"

    suspend fun search(query: String): List<Place> = withContext(Dispatchers.IO) {
        val url = "$NOMINATIM/search?format=jsonv2&limit=6&countrycodes=in&bounded=1" +
            "&accept-language=en&viewbox=${DelhiBounds.VIEWBOX}&q=${enc(query)}"
        val arr = JSONArray(httpGet(url))
        val out = ArrayList<Place>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(
                Place(
                    name = shorten(o.optString("display_name")),
                    lat = o.getString("lat").toDouble(),
                    lon = o.getString("lon").toDouble()
                )
            )
        }
        out.distinctBy { it.name }
    }

    /** Returns a readable name for a coordinate, or null if none is found. */
    suspend fun reverse(lat: Double, lon: Double): String? = withContext(Dispatchers.IO) {
        val url = String.format(
            Locale.US,
            "%s/reverse?format=jsonv2&zoom=18&accept-language=en&lat=%.6f&lon=%.6f",
            NOMINATIM, lat, lon
        )
        val json = JSONObject(httpGet(url))
        if (json.has("error")) null else shorten(json.optString("display_name"))
    }

    suspend fun route(from: Place, to: Place): RouteResult = withContext(Dispatchers.IO) {
        val coords = String.format(
            Locale.US, "%.6f,%.6f;%.6f,%.6f", from.lon, from.lat, to.lon, to.lat
        )
        val url = "$OSRM/route/v1/driving/$coords?overview=full&geometries=geojson"
        val json = JSONObject(httpGet(url))
        if (json.optString("code") != "Ok") throw IOException("No route found")

        val r = json.getJSONArray("routes").getJSONObject(0)
        val line = r.getJSONObject("geometry").getJSONArray("coordinates")
        val points = ArrayList<GeoPoint>(line.length())
        for (i in 0 until line.length()) {
            val c = line.getJSONArray(i)
            points.add(GeoPoint(c.getDouble(1), c.getDouble(0))) // GeoJSON is [lon, lat]
        }
        RouteResult(r.getDouble("distance"), r.getDouble("duration"), points)
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    /** "Connaught Place, Janpath, New Delhi, Delhi, 110001, India" -> first 3 useful parts. */
    private fun shorten(displayName: String): String {
        val parts = displayName.split(",")
            .map { it.trim() }
            .filter { it.isNotEmpty() && it != "India" && !it.matches(Regex("\\d{6}")) }
            .take(3)
        return if (parts.isEmpty()) displayName else parts.joinToString(", ")
    }

    private fun httpGet(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 10_000
            c.readTimeout = 15_000
            c.setRequestProperty("User-Agent", USER_AGENT)
            c.setRequestProperty("Accept", "application/json")
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }
}
