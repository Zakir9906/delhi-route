package com.example.delhiroute

import android.content.Context
import android.widget.ArrayAdapter
import android.widget.Filter

/**
 * Dropdown adapter whose contents are set by us (from the network) rather than
 * filtered by the typed text, so "cp" can still suggest "Connaught Place".
 */
class PlaceAdapter(context: Context) :
    ArrayAdapter<Place>(context, R.layout.item_suggestion, mutableListOf<Place>()) {

    private var items: List<Place> = emptyList()

    private val passThroughFilter = object : Filter() {
        override fun performFiltering(constraint: CharSequence?): FilterResults {
            val snapshot = items
            return FilterResults().apply {
                values = snapshot
                count = snapshot.size
            }
        }

        override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
            if (items.isNotEmpty()) notifyDataSetChanged() else notifyDataSetInvalidated()
        }
    }

    fun submit(newItems: List<Place>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun getCount(): Int = items.size
    override fun getItem(position: Int): Place? = items.getOrNull(position)
    override fun getFilter(): Filter = passThroughFilter
}
