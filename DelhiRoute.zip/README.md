# Delhi Route Finder (Android)

Map of Delhi where the user picks a source and a destination, and the app shows
the route, the distance, and the approximate travel time.

- Search places (autocomplete) or long-press the map to drop a pin
- Swap source/destination, clear fields with the (x) icon
- Route drawn on the map; distance + approx. driving time shown in a card
- No API key needed: OpenStreetMap (osmdroid) + Nominatim + OSRM

Build the APK: push to GitHub -> Actions tab -> "Build APK" -> download artifact.
